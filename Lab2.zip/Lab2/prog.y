%{
#include<stdio.h>
void yyerror(char *s);
int yylex();
%}

%token NUM ADD ID SUB INT IF ELSE WHILE ASSIGN EQ SEMI LP RP LB RB GT
%start statements

%%
statements: statements statement
           |
           ;

statement: id_declare
        | if_statement else_statement
        | assign_statement SEMI
        | while_statement
        ;
id_declare: INT ID ASSIGN NUM SEMI
           ;
if_statement: IF LP exp RP LB statements RB
             ;
else_statement: ELSE tail
              |
              ;
while_statement: WHILE LP exp RP tail
                ;
tail:LB statements RB
    ;

assign_statement: ID ASSIGN exp
                ;
exp: exp EQ NUM
    |exp EQ ID
    | exp ADD NUM
    | exp ADD ID
    | exp SUB NUM
    | exp SUB ID
    | exp GT NUM
    | exp GT ID
    | NUM
    | ID      
    ;


%%

int main(){
    yyparse();
    printf("Parsing Finished\n");
    return 0;
    
}

void yyerror(char *s){
    fprintf(stderr,"error=%s\n", s);
}