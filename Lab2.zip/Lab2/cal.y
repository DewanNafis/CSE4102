%{
#include<stdio.h>
void yyerror(char *s);
int yylex();
%}

%token NUM ADD ID SUB
%start cal

%%
cal: exp;

exp: exp ADD NUM
    | exp ADD ID
    | exp SUB NUM
    | exp SUB ID
    | ID
    | NUM
    ;


%%

int main(){
    yyparse();
    printf("Parsing Finished\n");
    return 0;
    
}

void yyerror(char *s){
    fprintf(stderr,"error=%s\n", s);
}