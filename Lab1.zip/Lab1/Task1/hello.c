#include<stdio.h>

int main(){
    int a, b, c;
    a = 10;
    b = 20;
    c = a + b;
    printf("a = %d\n",a);
    return 0;
}